//
//  mustadeemApp.swift
//  mustadeem
//
//  Created by shaimaa abdulrahman althubaiti on 12/06/1445 AH.
//

import SwiftUI

@main
struct mustadeemApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
